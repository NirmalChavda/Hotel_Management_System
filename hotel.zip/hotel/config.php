<?php
$server = "localhost";
$username = "bluebird_user";
$password = "password";
$database = "bluebirdhotel";

$conn = mysqli_connect('localhost:4306','root','','bluebirdhotel');

if(!$conn){
    die("<script>alert('connection Failed.')</script>");
}
?>